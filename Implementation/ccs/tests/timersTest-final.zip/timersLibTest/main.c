/************************************************/
// System Includes - ARM
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/timer.h"
#include "driverlib/sysctl.h"
//#include "inc/tm4c123gh6pm.h"
//#include "inc/hw_nvic.h"
//#include "inc/hw_types.h"
//#include "inc/hw_ints.h"
//#include "driverlib/debug.h"
//#include "driverlib/fpu.h"
//#include "driverlib/gpio.h"
//#include "driverlib/systick.h"
//#include "driverlib/uart.h"
//#include "driverlib/pin_map.h"
//#include "utils/uartstdio.h"
/***********************************************/
// Libraries
#include "a.lib/gpio.h"
#include "a.lib/lcd.h"
#include "timers.h"
/***********************************************/

void TimerInterruptHandler(){
	gpioSetData(GPIO_PORTF,0x0C,~gpioGetData(GPIO_PORTF,0x0C));
    timerInterruptClear(TIMER_0);
}

int main(void){

	gpioSetMasterEnable(GPIO_PORTF);
	gpioSetDirection(GPIO_PORTF,0x0C,0x0C);
	gpioSetDigitalEnable(GPIO_PORTF,0x0C,0x0C);

	timerSetup(TIMER_0,TIMER_CONFIG_PERIODIC,10);
	timerStart(TIMER_0);

    while(1);
}


