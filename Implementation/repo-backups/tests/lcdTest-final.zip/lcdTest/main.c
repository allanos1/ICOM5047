/************************************************/
// System Includes - ARM
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/timer.h"
#include "driverlib/sysctl.h"
//#include "inc/tm4c123gh6pm.h"
//#include "inc/hw_nvic.h"
//#include "inc/hw_types.h"
//#include "inc/hw_ints.h"
//#include "driverlib/debug.h"
//#include "driverlib/fpu.h"
//#include "driverlib/gpio.h"
//#include "driverlib/systick.h"
//#include "driverlib/uart.h"
//#include "driverlib/pin_map.h"
//#include "utils/uartstdio.h"
/***********************************************/
// Libraries
#include "a.lib/gpio.h"
#include "a.lib/bluetooth.h"
#include "a.lib/uart.h"
#include "a.lib/lcdSerial.h"
/***********************************************/

int main(void){
	gpioSetMasterEnable(GPIO_PORTF);
	gpioSetDirection(GPIO_PORTF,0x04,0x04);
	gpioSetDigitalEnable(GPIO_PORTF,0x04,0x04);
	lcdSerialInit(LCDSERIAL_INIT_UART3);
	lcdSerialSetContrast(0x55);
	lcdSerialSetBrightness(0x55);
	lcdSerialCursorBlink();
	lcdSerialCursorLine2();
	lcdSerialWriteNumber(12.1332);
	lcdSerialCursorLine3();
	lcdSerialWriteNumberWithBounds(12.1332,2,2);
	lcdSerialCursorLine4();
	lcdSerialWriteString("Hello, World!");
	lcdSerialWriteStringInLine(LCDSERIAL_LINE_1,"Hello, World!");
	while(1);
}


